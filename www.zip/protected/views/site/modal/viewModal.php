<div id = "view" class = "over" style = "display:none;">
	<div class = "modal">
		<div class = "load"><img src = "/images/load.gif" /></div>
		<div class = "modal-inner" style = "max-width:600px!important;">
			<a href = "javascript:hide();">Закрыть</a>
			<div id = "result"></div>
		</div>
	</div>
</div>
<script>
	function hide() {
		$('#view').hide();
	}
</script>