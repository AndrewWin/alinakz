<?php
	class Controller extends CController
	{
		public $breadcrumbs=array();	
	}
?>